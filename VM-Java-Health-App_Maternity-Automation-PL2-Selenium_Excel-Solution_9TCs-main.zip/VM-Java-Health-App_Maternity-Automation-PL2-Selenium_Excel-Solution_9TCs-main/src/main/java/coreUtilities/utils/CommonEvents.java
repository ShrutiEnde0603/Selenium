package coreUtilities.utils;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonEvents {
    private WebDriver driver;
    private WebDriverWait wait;
    private JavascriptExecutor js;

    public CommonEvents(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js = (JavascriptExecutor) driver;
    }

    public void navigateTo(String url) {
        driver.get(url);
    }

    public WebElement waitForElement(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void click(By locator) {
        waitForElement(locator).click();
    }

    public void type(By locator, String text) {
        WebElement ele = waitForElement(locator);
        ele.clear();
        ele.sendKeys(text);
    }

    public String getText(By locator) {
        return waitForElement(locator).getText();
    }

    public String getAttribute(By locator, String attr) {
        return waitForElement(locator).getAttribute(attr);
    }

    // ✅ two versions of highlightElement
    public void highlightElement(By locator) {
        WebElement ele = waitForElement(locator);
        highlightElement(ele);
    }

    public void highlightElement(WebElement element) {
        js.executeScript("arguments[0].style.border='3px solid red'", element);
    }

    public void scrollTo(By locator) {
        WebElement ele = waitForElement(locator);
        js.executeScript("arguments[0].scrollIntoView(true);", ele);
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getTitle() {
        return driver.getTitle();
    }
}

//package pages;
//
//import java.time.Duration;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import coreUtilities.utils.CommonEvents;
//
//
//public class StartupPage {
//	
//	public WebDriver driver;
//	public CommonEvents commonEvents;
//	//public UserActions userActions;	
//	public StartupPage(WebDriver driver) {
//		this.driver = driver;
//		commonEvents = new CommonEvents(driver);
//	}
////	
//////	public LoginPage navigateToLoginPage() {
//////		return new LoginPage(driver);
//////	}
////	
//	public void navigateToUrl(String url) throws Exception {
//		
//		commonEvents.navigateTo(url);		 
//	}
//	  
//	// StartupPage.java
//	  public WebElement waitForElement(By locator) {
//	      return commonEvents.waitForElement(locator);
//	  }
//
//	  public void clickElementByJS(WebElement element) {
//	      commonEvents.highlight(element);  // optional
//	      ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
//	  }
//
//	  public void type(By locator, String text) {
//	      commonEvents.type(locator, text);
//	  }
//	  
//	   // Scroll to element
//	    public void scrollTo(By locator) {
//	        WebElement ele = waitForElement(locator);
//	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
//	    }
//
//	    // Get current URL
//	    public String getCurrentUrl() {
//	        return driver.getCurrentUrl();
//	    }
//
//}


package pages;

import org.openqa.selenium.*;
import coreUtilities.utils.CommonEvents;

public class StartupPage {

    public WebDriver driver;
    public CommonEvents commonEvents;

    public StartupPage(WebDriver driver) {
        this.driver = driver;
        commonEvents = new CommonEvents(driver);
    }

    public void navigateToUrl(String url) {
        commonEvents.navigateTo(url);
    }

    public WebElement waitForElement(By locator) {
        return commonEvents.waitForElement(locator);
    }

    public void clickElementByJS(WebElement element) {
        commonEvents.highlightElement(element); // ✅ fixed call
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    public void type(By locator, String text) {
        commonEvents.type(locator, text);
    }

    public void scrollTo(By locator) {
        WebElement ele = waitForElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    // ✅ wrapper for getAttribute
    public String getAttribute(By locator, String attr) {
        return commonEvents.getAttribute(locator, attr);
    }
}

